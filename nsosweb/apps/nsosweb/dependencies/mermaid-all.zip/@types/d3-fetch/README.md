# Installation
> `npm install --save @types/d3-fetch`

# Summary
This package contains type definitions for d3-fetch (https://d3js.org/d3-fetch/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-fetch.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: [@types/d3-dsv](https://npmjs.com/package/@types/d3-dsv)

# Credits
These definitions were written by [Hugues Stefanski](https://github.com/ledragon), [denisname](https://github.com/denisname), and [Nathan Bierema](https://github.com/Methuselah96).
