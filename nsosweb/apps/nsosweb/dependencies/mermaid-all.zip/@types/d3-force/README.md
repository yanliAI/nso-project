# Installation
> `npm install --save @types/d3-force`

# Summary
This package contains type definitions for d3-force (https://github.com/d3/d3-force/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/d3-force.

### Additional Details
 * Last updated: Mon, 17 Jun 2024 20:07:03 GMT
 * Dependencies: none

# Credits
These definitions were written by [Tom Wanzek](https://github.com/tomwanzek), [Alex Ford](https://github.com/gustavderdrache), [Boris Yankov](https://github.com/borisyankov), [denisname](https://github.com/denisname), and [Nathan Bierema](https://github.com/Methuselah96).
