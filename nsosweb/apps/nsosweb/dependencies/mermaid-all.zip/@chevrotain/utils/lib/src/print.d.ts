export declare function PRINT_ERROR(msg: string): void;
export declare function PRINT_WARNING(msg: string): void;
