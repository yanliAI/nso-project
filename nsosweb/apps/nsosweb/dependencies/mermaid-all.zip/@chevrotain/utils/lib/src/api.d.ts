export { PRINT_WARNING, PRINT_ERROR } from "./print.js";
export { timer } from "./timer.js";
export { toFastProperties } from "./to-fast-properties.js";
