See: https://chevrotain.io/docs/changes/BREAKING_CHANGES.html
