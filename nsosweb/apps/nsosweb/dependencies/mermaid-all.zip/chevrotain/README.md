# Chevrotain

For details see:

- Chevrotain's [website](https://chevrotain.io/docs/).
- Chevrotain's root [README](https://github.com/chevrotain/chevrotain).

## Install

Using npm:

```sh
npm install chevrotain
```

or using yarn:

```sh
yarn add chevrotain
```
