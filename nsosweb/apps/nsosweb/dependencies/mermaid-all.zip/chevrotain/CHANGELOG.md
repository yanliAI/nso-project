See: https://chevrotain.io/docs/changes/CHANGELOG.html
