/**
 * Get rotation value
 */
declare function rotateFromString(value: string, defaultValue?: number): number;

export { rotateFromString };
