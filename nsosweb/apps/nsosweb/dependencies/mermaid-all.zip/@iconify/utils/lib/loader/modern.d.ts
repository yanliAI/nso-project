import { IconifyJSON } from '@iconify/types';
import { IconifyLoaderOptions } from './types.js';
import '@antfu/utils';
import '../customisations/defaults.js';

declare function searchForIcon(iconSet: IconifyJSON, collection: string, ids: string[], options?: IconifyLoaderOptions): Promise<string | undefined>;

export { searchForIcon };
