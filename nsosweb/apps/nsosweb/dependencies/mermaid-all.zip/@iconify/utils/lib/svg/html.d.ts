/**
 * Generate <svg>
 */
declare function iconToHTML(body: string, attributes: Record<string, string>): string;

export { iconToHTML };
