import { AutoInstall } from './types.js';
import '@antfu/utils';
import '../customisations/defaults.js';
import '@iconify/types';

declare function tryInstallPkg(name: string, autoInstall: AutoInstall): Promise<void | undefined>;

export { tryInstallPkg };
