/**
 * Remove whitespace
 */
declare function trimSVG(str: string): string;

export { trimSVG };
