import { UniversalIconLoader } from './types.js';
import '@antfu/utils';
import '../customisations/defaults.js';
import '@iconify/types';

declare const loadNodeIcon: UniversalIconLoader;

export { loadNodeIcon };
