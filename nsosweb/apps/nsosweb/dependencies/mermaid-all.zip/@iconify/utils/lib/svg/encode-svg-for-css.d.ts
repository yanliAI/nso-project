/**
 * Encode the `SVG` to be used on `CSS`: https://bl.ocks.org/jennyknuth/222825e315d45a738ed9d6e04c7a88d0.
 *
 * @param svg The `SVG` source.
 */
declare function encodeSvgForCss(svg: string): string;

export { encodeSvgForCss };
