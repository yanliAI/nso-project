import { IconifyTransformations } from '@iconify/types';

/**
 * Merge transformations
 */
declare function mergeIconTransformations<T extends IconifyTransformations>(obj1: T, obj2: IconifyTransformations): T;

export { mergeIconTransformations };
