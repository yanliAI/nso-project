/**
 * Get boolean customisation value from attribute
 */
declare function toBoolean(name: string, value: unknown, defaultValue: boolean): boolean;

export { toBoolean };
