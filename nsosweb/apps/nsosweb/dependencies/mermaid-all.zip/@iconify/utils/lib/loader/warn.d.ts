declare function warnOnce(msg: string): void;

export { warnOnce };
