/**
 * Prettify SVG
 */
declare function prettifySVG(content: string, tab?: string, depth?: number): string | null;

export { prettifySVG };
