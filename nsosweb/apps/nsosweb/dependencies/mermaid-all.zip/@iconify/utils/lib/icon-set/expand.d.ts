import { IconifyJSON } from '@iconify/types';

/**
 * Expand minified icon set
 *
 * Opposite of minifyIconSet() from ./minify.ts
 */
declare function expandIconSet(data: IconifyJSON): void;

export { expandIconSet };
