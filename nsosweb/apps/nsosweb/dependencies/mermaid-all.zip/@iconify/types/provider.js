/**
 * Empty file. This repository contains only TypeScript types
 */
