import layout from './layout/index.mjs';
import renderer from './renderer/index.mjs';

export default [
  {
    type: 'layout',
    extensions: layout
  },

  {
    type: 'renderer',
    extensions: renderer
  }
];
